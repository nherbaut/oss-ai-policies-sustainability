# GenAI Effects on OSS Sustainability — Research Handoff

## Research objective
Develop a theory-grounded, extensible qualitative coding taxonomy for the **effects and anticipated effects of generative AI (GenAI) on open-source software (OSS) projects**, using OSS AI policy texts as the empirical corpus. Combine deductive categories from the sustainability literature with inductively identified codes. Avoid treating policy assertions as demonstrated consequences.

## Theoretical model
Use the Karlskrona Manifesto for Sustainability Design (https://sustainabilitydesign.org/karlskrona-manifesto/) to define **five dimensions**: Environmental, Technical, Social, Economic, Individual. Treat **first-, second-, and third-order effects** as a separate, orthogonal axis; use concentric circles for visualization only. Consider temporal horizons and cross-dimensional trade-offs separately.

Clarify first-order effects as direct effects attributable to technology production/existence and operation; second-order as effects of application/use; third-order as structural/systemic effects from widespread use. Assign orders to concrete *effects*, not automatically to categories or policies.

## Primary source
Roy et al. (2026), *Towards a Taxonomy of Sustainability Requirements for Software Design*, in `sources/sus-taxo.pdf`. Full companion material is provided in `sources/`:
- `Categories & Metrics.docx`: reference categories and metrics (20 categories in four dimensions)
- `Taxonomy_created.csv`: 250 requirement rows, columns Requirement ID, Requirement, Dimension, Issue. **Read with cp1252 encoding**; labels include typos, inconsistent case, and dimensions outside the canonical four. Preserve raw values and create a separate normalized layer.
- `Sustainability Category Correlations.xlsx`: authors' correlations; verify matrix meaning and any counting before making claims.
- `Research Papers Surveyed For Taxonomy.docx`: author survey references, not necessarily full-text evidence.
- `README(2).md`: companion repository description.
- `categories and metrics.png`: visual summary of original categories and metrics.

## Baseline categories — source-authored (retain original labels)
**Environmental (5):** Carbon Footprint; Energy Consumption; E-waste; Code Sustainability; Resource management.

**Technical (5):** Perdurability; Longitivity [source image spelling; elsewhere Longitivity/Longeitivity; standardize only in normalized field]; Repairability; Feature Bloat; Security Concerns.

**Social (6):** Digital Inclusivity; Equitable Access; Ethical Concerns; Customer social value; Social Engineering; User error protection.

**Economic (4):** Circular Economy; Affordability; Cost efficiency; Software process evolving intellectual capital.

Do not silently reassign source categories to different dimensions or collapse overlapping ones.

## Preliminary individual sustainability extension — NOT from Roy et al.'s final taxonomy
**Individual (5):** Health; Lifelong learning; Privacy; Safety; Agency. These terms appear in `Categories & Metrics.docx` as a summary of sustainability awareness framework literature (including Duboc et al., 2020 and a 2019 work). Verify against the *original papers* before claiming precise definitions. These are provisional, not yet a rigorously validated taxonomy extension.

Current provisional baseline: **25 categories across five dimensions** (20 original + 5 individual candidates).

## Coding architecture
Maintain separate fields:
1. Source document / source span / exact quote and citation
2. Actor/stakeholder affected (individual contributor, maintainer, project, community, downstream user, ecosystem, etc.)
3. Sustainability dimension (multi-label if justified)
4. Category and optional subcategory (retain raw and normalized names)
5. Sustainability effect or concern (explicitly stated vs inferred)
6. Order of effect (1/2/3, if warranted; unresolved allowed)
7. Direction (benefit / harm / trade-off / ambiguous / not specified)
8. Policy mechanism (prohibition, disclosure, review, accountability, licensing, data use, etc.; separate from effect)
9. Evidence status (policy claim, theoretically inferred consequence, empirically observed outcome)
10. Provenance and confidence / coder memo

Distinguish: (a) what a policy **prescribes**, (b) the **concern** motivating it, (c) the possible sustainability **effect**, and (d) evidence that an effect actually occurs. A rule requiring human review of AI-generated code does not by itself prove loss of skills, technical deterioration, or systemic change.

## Next research tasks
1. Inspect the original 20 categories and their definitions/metrics from the DOCX, CSV and workbook; record source-specific spelling and cross-document mismatches.
2. Build a machine-readable master `taxonomy.csv` with category ID, dimension, raw label, normalized label, definition, source, status (`original`, `literature extension`, `inductive`).
3. Link each original requirement to categories without silently forcing unmatched issues to an existing category; preserve raw issues and maintain an 'unmapped' state.
4. Extract and document correlation relationships and their source; treat as posited influences, not causal evidence.
5. As new papers are provided, critically extract individual or other sustainability categories, with exact evidence quotes, pages, distinctions from existing categories, and OSS/GenAI applicability.
6. Construct a transparent qualitative coding guide (inclusion/exclusion rules, examples, multiple coding, uncertain cases) and assess inter-coder agreement when corpus coding begins.
7. Produce a conceptual visualization with five dimensions and concentric circles for orders, while keeping order assignments independent from categories.

## Important methodological cautions
- The Karlskrona framework motivates broad sustainability reasoning; it does not establish empirical effects of GenAI on OSS.
- A category is **not** an effect. An OSS policy statement is **not** necessarily evidence of the effect it anticipates.
- Preserve provenance: distinguish author's original categories, literature-grounded extensions, researcher inference, and inductive codes.
- Some source labels and issue assignments are inconsistent; treat cleaning as an explicit data-processing operation.
