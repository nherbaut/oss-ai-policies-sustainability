# AI Usage Policy

The pyinfra project has strict rules for AI usage:

- **All AI usage in any form must be disclosed.** You must state the tool you used (e.g. Claude
  Code, Cursor, Amp) along with the extent that the work was AI-assisted.

- **The human-in-the-loop must fully understand all code.** If you can't explain what your changes
  do and how they interact with the greater system without the aid of AI tools, do not contribute
  to this project.

- **Issues and discussions can use AI assistance but must have a full human-in-the-loop.** This
  means that any content generated with AI must have been reviewed _and edited_ by a human before
  submission. AI is very good at being overly verbose and including noise that distracts from the
  main point. Humans must do their research and trim this down.

- **No AI-generated media is allowed (art, images, videos, audio, etc.).** Text and code are the
  only acceptable AI-generated content, per the other rules in this policy.

## There are Humans Here

Please remember that pyinfra is maintained by humans.

Every discussion, issue, and pull request is read and reviewed by humans (and sometimes machines,
too). It is a boundary point at which people interact with each other and the work done. It is
rude and disrespectful to approach this boundary with low-effort, unqualified work, since it puts
the burden of validation on the maintainer.

In a perfect world, AI would produce high-quality, accurate work every time. But today, that
reality depends on the driver of the AI. And today, most drivers of AI are just not good enough.
So, until either the people get better, the AI gets better, or both, we have to have strict rules
to protect maintainers.

## AI is Welcome Here

pyinfra is written with plenty of AI assistance, and many maintainers embrace AI tools as a
productive tool in their workflow. As a project, we welcome AI as a tool!

**Our reason for the strict AI policy is not due to an anti-AI stance**, but instead due to the
number of highly unqualified people using AI. It's the people, not the tools, that are the problem.

I include this section to be transparent about the project's usage about AI for people who may
disagree with it, and to address the misconception that this policy is anti-AI in nature.

## Attribution

This policy is based on the AI Usage Policy of the
[Ghostty project](https://github.com/ghostty-org/ghostty/blob/main/AI_POLICY.md).
