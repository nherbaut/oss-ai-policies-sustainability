# AI Usage Policy

The Zeek project has strict rules for AI usage:

- **AI usage in any form must be disclosed.** You must state the tool you used (e.g. Claude Code, Cursor, Amp) along with the extent to which your work was AI-assisted.

- **The human-in-the-loop must fully understand all code.** If you can't explain what your changes do and how they interact with the greater system without the aid of AI tools, do not contribute to this project.

- **Contributions and communication with us can use AI assistance but must have a human-in-the-loop.** This means that any content generated with AI must have been reviewed and edited by a human before submission. AI is very good at being overly verbose and including noise that distracts from the main point. Please do your research and trim this down.

- **No AI-generated media is allowed (art, images, videos, audio, etc.).** Text, code, and Pcaps (see below) are the only acceptable AI-generated content, per the other rules in this policy.

- **AI generated Pcap files require submission of source code.** Packet captures created by AI-generated scripts/code (e.g. Python's Scapy library) are acceptable as long as they follow the same disclosure rules. The script that generated the Pcap must be checked in alongside the Pcap using the same name with a .py suffix. The script should contain a doc string with a description of the traffic generated as well as a line indicating what model was used to generate it.

## There are Humans Here

Please remember that Zeek is maintained by humans.

Every discussion, issue, and pull request is read and reviewed by humans (and sometimes machines, too). It is a boundary point at which people interact with each other and the work done. It is rude and disrespectful to approach this boundary with low-effort, unqualified work, since it puts the burden of validation on the maintainer.

In a perfect world, AI would produce high-quality, accurate work every time. But today, that reality depends on the driver of the AI. And today, most drivers of AI are just not good enough. So, until either the people get better, the AI gets better, or both, we have to have strict rules to protect maintainers.

**Our reason for the strict AI policy is not due to an anti-AI stance**, but instead due to inconsiderate use of AI.

This policy is based on the [Ghostty AI Usage Policy](https://github.com/ghostty-org/ghostty/blob/main/AI_POLICY.md).
