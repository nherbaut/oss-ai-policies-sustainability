<!---
SPDX-FileCopyrightText: © 2026 Alexandros Theodotou
SPDX-License-Identifier: FSFAP
-->

# Changelog
All notable changes to this project will be documented in this file.

For changes prior to v2.0.0, see [CHANGELOG-old.v1.md](CHANGELOG-old.v1.md).

## [v2.0.0-alpha.7] - 2026-10-25

### Added
- Selected notes, audio and automation can be transformed from the
  clip editors' Functions menu (#5328): MIDI notes get Crescendo,
  Flam, Flip Horizontal/Vertical, Legato, Portato, Staccato and
  Strum, audio clips get Invert Polarity, Reverse, Normalize Peak/RMS
  and curved Fade In/Out, and automation points get Flip
  Horizontal/Vertical and Flatten. Functions with parameters open a
  dialog, remember their last-used values and apply as one undo step
- Transform Stack panel in the audio editor: audio functions are
  kept as ordered, non-destructive entries over a time range, with
  controls to bypass, remove, reorder and bake them and with the
  affected range highlighted in the clip
- Color picker for tracks and clips, reachable from the track
  inspector and a new Color… entry in the arranger context menu, with
  swatches, a custom color and a reset to the track type's default
- GNU/Linux AppImages for aarch64, built next to the x86_64 ones;
  AppImage file names now include the CPU architecture

### Changed
- Project audio is stored in blocks, and identical audio is stored
  once; recordings are written to disk as they arrive, and backups
  and Save As copy only the audio the project references, including
  audio recorded while the save runs
- Projects saved by earlier alphas no longer load: the audio pool
  uses the new block-based format instead of whole-file WAVs
- The startup window opens the project selector immediately while
  plugins scan in the background with a progress indicator; the
  first-run configuration page and scanning screen are gone
- Recent projects show relative save dates in a card with a clear
  action and an empty state, the create page is a labeled form with
  name, location and template, and a warning appears when no audio
  device could be opened
- Tracks get a type-derived default color when no color is set,
  drawn as a thin strip in the tracklist and mixer, and the folder
  expander now sits on the name row
- All arranger objects take their colors from the clip's color:
  notes, waveforms and automation curves use a deeper, more saturated
  shade, scale, chord, tempo and time-signature objects use a tinted
  background, markers are drawn as pennants, clips have one unbroken
  border and muted clips turn gray
- Settings are stored under new names, so the icon theme, recent
  projects, plugin search paths and user path fall back to their
  defaults once, and the welcome tour shows again once
- Open Project… now selects .zpj files directly instead of asking
  for a folder
- Sliders follow the design system, Filters/Presets/Functions share
  a labeled menu button, and dialogs opened inside the window center
  on it

### Fixed
- An idle project no longer keeps a CPU core busy: JUCE events are
  dispatched through Qt's event loop instead of a timer that fired
  continuously
- Systems without an audio input device now get output-only
  playback instead of no audio at all, with a warning; opening a
  project when no audio device is open shows an error instead of
  crashing
- Dragging a plugin onto a track while a background plugin scan
  runs no longer crashes, and plugin rows stay in place during the
  scan
- The new-project location field ignored the folder chosen in the
  dialog; the selection is now used and remembered as the default,
  and a reset button restores the factory location

## [v2.0.0-alpha.6] - 2026-10-04

### Added
- File import (#5197, #5325): MIDI files import as tracks with one
  clip per MIDI track on its own lane and into clip launcher
  slots, undoable as a single step; audio and MIDI files can be
  dropped onto the timeline at the snapped position (multi-file
  drops stack clips in consecutive lanes, drops below the
  tracklist create one track per file) or imported through an
  "Import File…" picker in the File menu and the tracklist header
- The playhead and its glow turn red while recording, and the
  record button and a status bar indicator blink while recording
  is active
- A --verify-installation command line option that checks the
  installation layout and exits

### Changed
- The mixer strip and track headers regroup their state controls
  at a compact size: solo, mute, record and listen sit together,
  the mono, phase and monitor controls appear only when one of
  them is active, and automation lane controls follow the same
  sizing
- Recording (record buttons, playhead) and destructive or failure
  states (delete rubber band, cut tool, meter over-levels) use
  separate record and error colors that meet contrast requirements
  in both themes
- File dialogs are native on GNU/Linux through the XDG desktop
  portal and support multiple selection

### Fixed
- Undo and redo leaving clips invisible when their lane was
  trimmed away after becoming empty: lanes are restored at their
  position, and lanes emptied by clip removals collapse back to a
  single trailing empty lane (#5325)
- LV2 plugins leaking resources they schedule for release through
  the worker extension when destroyed
- LV2 plugins failing to scan in packaged macOS and Windows builds
  because the LV2 spec files were missing from the app bundle and
  installer; startup now verifies the installation and reports
  fatal errors in a dialog

### Removed
- The legacy sample processor (unused)

## [v2.0.0-alpha.5] - 2026-09-30

### Added
- Native LV2 plugin hosting replacing the JUCE wrapper: metadata-only
  discovery via lilv that never loads plugin binaries during
  scanning, host transport and MIDI delivered as atom sequences,
  worker extension hosting, pset presets, default states and
  patch:writable parameters exposed as automatable parameters, and
  self-contained state blobs that embed files created through
  state:makePath
- Native LV2 plugin UIs (X11) hosted in real windows on GNU/Linux,
  embedded under Wayland via XWayland, following the UI's own size
  and resize requests
- CLAP preset discovery and loading driven by each plugin's own
  preset-discovery providers
- Undoable clipboard operations (copy, cut, paste, duplicate) for
  arranger objects, tracks and plugins (#5172): shortcuts, menu
  items and Delete follow the focused view, pasted tracks keep
  their folder nesting and output routing, editor arrangers paste
  into the edited clip at the playhead, and payloads sync with the
  OS clipboard so selections can be pasted across projects and
  instances
- Notification center replacing modal alerts (#5324): toasts that
  coalesce repeated occurrences and can carry an action supplied by
  the producer, a bell badging unacknowledged warnings and errors,
  and a history popover with relative timestamps
- Status bar showing the audio engine's sample rate, buffer size
  and the project's track count
- Undoable lane deletion from the lane context menu; laned tracks
  keep a trailing empty lane for placing new clips (#5172)
- Plugin browser favorites, persisted per plugin, with a favorites
  filter and a plugin info dialog; browser rows show vendor
  subtitles with show-in-file-manager and import actions
- Third-party licenses page in the About dialog listing every
  shipped component with its copyright and license texts
- Menu items showing their shortcut right-aligned

### Changed
- The UI follows a new design system specification: dialogs render
  as native windows with emphasized default buttons activated by
  Return from anywhere, menus and combo popups share spacing and
  typography rules with animated color transitions, selected
  arranger objects draw a text-colored outline, and recording and
  error states use distinct shades of red
- The Greeter's recent projects list uses two-line rows with
  show-in-file-manager and remove-from-list actions
- Update translations (Swedish, Czech, Spanish, French, Russian,
  Ukrainian and more)

### Fixed
- Parameter edits made in plugin UIs (VST3, CLAP) are
  attributed as user edits: they mark the selected preset dirty and
  coalesce into one undo step instead of flooding the undo history
- VST3 parameters reported by the plugin during processing not
  reaching the host parameter model, separate edit controllers not
  being notified of applied values, and dual-component plugins
  appearing twice in scans
- Crashes in dlopened pango-based plugin UIs (e.g. avldrums) caused
  by internally bundled harfbuzz/freetype copies shadowing the
  system libraries
- Scans of bundles containing no plugins (e.g. preset-only
  bundles) timing out and blacklisting the scanned path
- The Greeter re-showing the last alert when a project closes, and
  its page stack growing on repeated load failures (#5324)
- The audio engine accepting deactivation during an offline render,
  leaving the render thread processing without a device callback
- Periodic plugin parameter flushes slowing down over a session as
  the undo history accumulated removed plugins

### Removed
- JUCE LV2 hosting and the vendored LV2 headers, replaced by the
  native lilv-based hosting

## [v2.0.0-alpha.3] - 2026-09-03

### Added
- Native VST3 plugin hosting replacing the JUCE wrapper, with
  resizable embedded editor windows featuring a header strip, bypass
  and A/B state comparison
- Durable preset selection with VST3 program tracking, a prev/next
  preset selector in plugin windows, and a searchable preset browser
  with group filtering and keyboard auditioning
- Parameter groups (e.g. VST3 units) shown as sections in the
  generic plugin parameter editor
- Diagnostics row in plugin windows showing DSP load and latency
  (#4526)
- Host transport (play state, tempo, time signature and musical
  position) delivered to VST3 and CLAP plugins, so tempo-synced
  plugins follow the project
- Parallel polyphonic voice rendering for bundled synths on a
  realtime-safe worker pool, and hosting of the CLAP thread-pool
  extension for plugins that parallelize their processing
- Drag and wheel scrubbing on the transport bar BPM, time signature
  and position readouts (Shift/Ctrl for fine steps)
- Pinned-cursor dragging with Shift fine mode for knobs, faders and
  balance controls, so values can be edited indefinitely without the
  cursor hitting screen edges
- Type and format filters with persisted search in the plugin browser
- Per-stage progress reporting for project load and save, and a
  modal dialog that blocks concurrent project loads
- System information and a Copy System Info button in the About
  dialog
- Windows on ARM installers built as ARM64EC, running natively while
  loading x64 plugins in-process

### Changed
- Multi-channel audio routing reworked around speaker arrangements:
  audio folds between layouts per ITU-R BS.775 instead of silencing
  unmatched buses, port connections carry explicit channel routings,
  and plugin bus changes at runtime detach and revive ports without
  losing connections
- Sidechain buses are excluded from automatic track chain wiring and
  connect through explicit user connections
- The playhead keeps its musical position across tempo changes, and
  engine-internal pauses (e.g. for undo) no longer trigger
  return-to-cue moves

### Fixed
- Plugin parameters being zeroed on the first processing cycle,
  resetting patches of plugins like Surge XT
- Crash when removing a MIDI device while its processor is part of
  the processing graph (#5284)
- Backups cloning their pool files over the main project's pool
  files (reversed copy direction in the reflink path)
- Crash on port connections referencing nonexistent endpoints; such
  connections are now dropped with a warning at load
- Data races between the main and audio threads on transport state
  and playhead processing state (ThreadSanitizer)
- Deadlocks when graph recalculation or engine pausing was requested
  while already in progress
- Count-in metronome clicks continuing to play after pausing during
  the count-in
- Faders and balance controls resetting to hardcoded values instead
  of the parameter default, and the fader hover label showing
  -2.1 dB at unity gain (#5307)
- Faders ramping to new volumes faster than real time during
  playback
- Generic plugin editor windows opening without a title bar on
  Windows
- Unstyled platform scrollbars and fallback controls on Windows
  (#5312)
- Arrangers setting drag cursors when the pointer is elsewhere in
  the window
- Missing icon error in the track inspector's MIDI input expander
- DSP load indicator rendering an empty meter as a solid block

### Removed
- Carla plugin hosting support (already disabled)

## [v2.0.0-alpha.2] - 2026-07-29

### Added
- Chord pad panel with preset/scale support, polyphonic audition and
  undoable editing (#5169)
- Chord editor for placing and editing chord objects in progressions
  (#5169)
- Chord suggestion engine that recommends next chords based on the
  current chord and scale
- Chord symbols displayed inside chord clips on the timeline
- Chord track recording, including from chord pad notes (#5281)
- Musical mode: time-stretch audio clips to follow the project tempo
  (offline Rubberband), toggleable globally and per clip (#4368)
- Source BPM detection from audio file metadata, with automatic tempo
  estimation when metadata is missing (#4746)
- Pencil tool for creating objects; hold Ctrl and drag to paint
  consecutive objects (#5178)
- Eraser tool for deleting objects by clicking or dragging a rectangle
  (also via right-drag) (#5180)
- Cut tool for splitting objects at the clicked position (Alt+click)
  (#5179)
- Ramp tool for drawing linear velocity ramps across MIDI notes (#5181)
- Audition tool for playing from the clicked position while held
  (#5182)
- Editable base tempo and base time signature anchored at the start of
  the timeline
- BPM cell in the transport bar showing the tempo at the playhead,
  editable via an undoable dialog
- Tempo automation curve drawn behind tempo objects
- Draggable clip-start, loop-start and loop-end markers on the clip
  editor ruler
- Undo/Redo actions in the Edit menu showing the next action name
- Panel toggle buttons in the toolbar and View menu
- Generic parameter editor window for plugins without a native UI
- Open .zpj project files from file managers or the command line
  (#5275)
- MIDI note activity highlighting on piano roll keys
- Undoable velocity editing with per-note clamping and live value labels
- Alternating bar shading in the arranger background
- Language menu with per-language completion percentages and a "More
  Languages" submenu
- Optional Tracy profiler integration

### Changed
- Rename "regions" to "clips" throughout the UI and project format
  (#4368)
- Reimplement bundled Faust plugins as internal plugins instead of
  generated VST3/CLAP bundles
- Switch most dependency management from CPM to Conan
- Rebuild the live waveform, spectrum analyzer and meter displays on a
  new real-time-safe port observation system
- Rework automation rendering with a C++ canvas painter and
  segment-based curve evaluation on the audio thread
- Arranger drags and resizes now preview in place and commit as a
  single undo step on release
- Default to dark mode on startup
- Update translations (Spanish, Ukrainian, Chinese Simplified, German,
  Russian, French, Japanese and more)

### Fixed
- Faders, knobs and balance controls getting stuck when a parent
  scroll view takes over the drag (#5308)
- Crash from wrapped 32-bit MIDI timestamps after ~50 days of system
  uptime (Linux ALSA)
- Track name field keeping stale text and staying in edit mode when
  switching tracks (#5220)
- Deleting or cloning tempo and time signature objects failing
- Incorrect note-offs with overlapping same-pitch MIDI notes (#5279)
- Distorted automation curves when tempo changes occur within a clip
- Track selection pointing at the wrong track when tracks are hidden
- Selections of non-moved tracks being lost when moving tracks
- Stale entries for deleted plugin files shown in the plugin browser
- Failed plugin instantiation leaving broken tracks; an error dialog is
  now shown instead
- Load/save dialogs not defaulting to the configured new-project
  directory (#5211)
- Dock panels resizing smaller than their content, and the bottom dock
  being cut off on first load
- Peak meter and fader value labels shifting the layout as values
  change

### Removed
- Legacy GTK-era code (widgets, actions, event manager, gschema
  generator)
- Legacy real-time audio stretcher (superseded by the offline
  time-stretch engine)

## [v2.0.0-alpha.1] - 2026-05-30

First official v2 alpha release. Zrythm v2 is a complete rewrite using Qt/QML
and JUCE, replacing the previous GTK-based UI.

### Added
- Qt/QML-based UI with hardware acceleration (Qt Quick)
- Plugin support via JUCE: VST3, LV2, LADSPA, AudioUnit
- Native plugin support: CLAP
- Tempo map with editable tempo and time signature objects
- ASIO support on Windows
- CPack packaging: AppImage (GNU/Linux), DragNDrop (macOS), InnoSetup (Windows)
- CI pipeline with Clang sanitizers, Valgrind, QML lint, ClangFormat checks
- Unit tests, integration tests, and benchmarks
- Use CPM for dependency management with version pinning

### Changed
- Migrated from GTK to Qt6/QML
- Migrated from Meson to CMake
- Migrated from C to C++23
- Bundled Faust plugins migrated from LV2 to JUCE/VST3

### Removed
- GTK, Carla, guile dependencies
- Meson build system
