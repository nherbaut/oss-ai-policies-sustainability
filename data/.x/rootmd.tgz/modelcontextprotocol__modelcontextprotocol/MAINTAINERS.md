# MCP Maintainers

This document lists current maintainers in the Model Context Protocol project.

**Last updated:** October 1, 2026

## Lead Maintainers

- [David Soria Parra](https://github.com/dsp-ant)
- [Den Delimarsky](https://github.com/localden)

## Core Maintainers

- [Caitie McCaffrey](https://github.com/CaitieM20)
- [Clare Liguori](https://github.com/clareliguori)
- [Kurtis Van Gent](https://github.com/kurtisvg)
- [Nick Cooper](https://github.com/nickcoai)
- [Paul Carleton](https://github.com/pcarleton)
- [Peter Alexander](https://github.com/poita)

## Emeritus

- [Justin Spahr-Summers](https://github.com/jspahrsummers) (Co-Inventor, Lead Maintainer Emeritus)
- [Basil Hosmer](https://github.com/bhosmer-ant) (Core Maintainer Emeritus)
- [Che Liu](https://github.com/pwwpche) (Core Maintainer Emeritus)
- [Nick Aldridge](https://github.com/000-000-000-000-000) (Core Maintainer Emeritus)

## SDK Maintainers

### Java SDK

- [Christian Tzolov](https://github.com/tzolov)
- [Dariusz Jędrzejczyk](https://github.com/chemicL)
- [Daniel Garnier-Moiroux](https://github.com/Kehrlann)
- [Mark Pollack](https://github.com/markpollack)

### Ruby SDK

- [Topher Bullock](https://github.com/topherbullock)
- [Koichi Ito](https://github.com/koic)
- [Ateş Göral](https://github.com/atesgoral)
- [Jonathan Hefner](https://github.com/jonathanhefner)

### Swift SDK

- [Matt Zmuda](https://github.com/mattt)
- [Carl Peaslee](https://github.com/carlpeaslee)
- [Maksym Mova](https://github.com/movetz)
- [Stephen Tallent](https://github.com/stallent)

### Go SDK

- [Maciej Kisiel](https://github.com/maciej-kisiel)
- [Yaroslav Shevchuk](https://github.com/yarolegovich)
- [Guglielmo Colombo](https://github.com/guglielmo-san)
- [Jonathan Amsterdam](https://github.com/jba)

### C# SDK

- [Stephan Halter](https://github.com/halter73)
- [Mike Kistler](https://github.com/mikekistler)
- [Den Delimarsky](https://github.com/dend)
- [Eirik Tsarpalis](https://github.com/eiriktsarpalis)
- [Stephen Toub](https://github.com/stephentoub)

### Kotlin SDK

- [Leonid Stashevsky](https://github.com/e5l)
- [Sergey Ignatov](https://github.com/ignatov)
- [Konstantin Pavlov](https://github.com/kpavlov)
- [Pavel Gorgulov](https://github.com/devcrocod)
- [Briliantov Vadim](https://github.com/Ololoshechkin)
- [Sergei Dubov](https://github.com/sdubov)
- [Maria Tigina](https://github.com/tiginamaria)

### Python SDK

- [Inna Harper](https://github.com/ihrpr)
- [Jerome Swannack](https://github.com/jerome3o)
- [Marcelo Trylesinski](https://github.com/Kludex)
- [Max Isbey](https://github.com/maxisbey)
- [Felix Weinberger](https://github.com/felixweinberger)

### TypeScript SDK

- [Inna Harper](https://github.com/ihrpr)
- [Felix Weinberger](https://github.com/felixweinberger)
- [Olivier Chafik](https://github.com/ochafik)
- [Konstantin Konstantinov](https://github.com/KKonstantinov)
- [Matt Carey](https://github.com/mattzcarey)

### Rust SDK

- [Alex Hancock](https://github.com/alexhancock)
- [Michael Bolin](https://github.com/bolinfest)
- [Bradley Axen](https://github.com/baxen)
- [Jack Amadeo](https://github.com/jamadeo)
- [Michael Neale](https://github.com/michaelneale)

### PHP SDK

- [Kyrian Obikwelu](https://github.com/CodeWithKyrian)
- [Christopher Hertel](https://github.com/chr-hertel)
- [Fabien Potencier](https://github.com/fabpot)
- [Nicolas Grekas](https://github.com/nicolas-grekas)
- [Tobias Nyholm](https://github.com/Nyholm)
- [Roman Pronskiy](https://github.com/pronskiy)

## Project Maintainers

### use-mcp

- [Glen Maddern](https://github.com/geelen)

### Inspector

- [Cliff Hall](https://github.com/cliffhall)
- [Konstantin Konstantinov](https://github.com/KKonstantinov)
- [Ola Hungerford](https://github.com/olaservo)
- [Bob Dickinson](https://github.com/BobDickinson)

### Registry

- [Tadas Antanavicius](https://github.com/tadasant)
- [Radoslav (Rado) Dimitrov](https://github.com/rdimitrov)
- [Bob Dickinson](https://github.com/BobDickinson)

#### Registry Emeritus

- [Adam Jones](https://github.com/domdomegg)
- [Toby Padilla](https://github.com/toby)

### MCPB (Model Context Protocol Bundle)

- [Alexander Sklar](https://github.com/asklar)
- [Adam Jones](https://github.com/domdomegg)
- [Joan Xie](https://github.com/joan-anthropic)

### Reference Servers

- [Ola Hungerford](https://github.com/olaservo)
- [Cliff Hall](https://github.com/cliffhall)
- [Tadas Antanavicius](https://github.com/tadasant)
- [Shaun Smith](https://github.com/evalstate)
- [Jonathan Hefner](https://github.com/jonathanhefner)

### Conformance

- [Paul Carleton](https://github.com/pcarleton)
- [Felix Weinberger](https://github.com/felixweinberger)
- [Takashi Norimatsu](https://github.com/tnorimat)

## Community Moderators

- [Ola Hungerford](https://github.com/olaservo)
- [Cliff Hall](https://github.com/cliffhall)
- [Shaun Smith](https://github.com/evalstate)
- [Jonathan Hefner](https://github.com/jonathanhefner)
- [Tadas Antanavicius](https://github.com/tadasant)
- [Peder Holdgaard Pedersen](https://github.com/PederHP)

## Working Group & Interest Group Maintainers

[Working Groups and Interest Groups](https://modelcontextprotocol.io/community/working-interest-groups) are not required to have maintainers (they can be managed by informal facilitators), but maintainers may be appointed on an as-needed basis.

### Security Interest Group

- [Den Delimarsky](https://github.com/dend)
- [Paul Carleton](https://github.com/pcarleton)
- [Jenn Newton](https://github.com/jenn-newton)

### Authorization Interest Group

- [Aaron Parecki](https://github.com/aaronpk)
- [Darin McAdams](https://github.com/D-McAdams)
- [Paul Carleton](https://github.com/pcarleton)

### Client Implementor Interest Group

**Note:** These individuals serve as MCP protocol representatives for their respective clients. For client-specific issues, use the official support channels provided by each product.

- [Alex Hancock](https://github.com/alexhancock) - Goose
- [Ben Brandt](https://github.com/benbrandt) - Zed
- [Connor Peet](https://github.com/connor4312) - VS Code
- [Gabriel Peal](https://github.com/gpeal) - Codex
- [Jun Han](https://github.com/formulahendry) - GitHub Copilot for JetBrains
- [Tyler Leonhardt](https://github.com/TylerLeonhardt) - VS Code
- [Michael Feldstein](https://github.com/msfeldstein) - Cursor

### Financial Services Interest Group

- [Sambhav Kothari](https://github.com/sambhav)
- [Peder Holdgaard Pedersen](https://github.com/PederHP)

### Transports Interest Group

- [Kurtis Van Gent](https://github.com/kurtisvg)
- [Jonathan Hefner](https://github.com/jonathanhefner)
- [Shaun Smith](https://github.com/evalstate)
- [Harvey Tuch](https://github.com/htuch)

### Server Card Working Group

- [Tadas Antanavicius](https://github.com/tadasant)
- [David Soria Parra](https://github.com/dsp-ant)
- [Sam Morrow](https://github.com/SamMorrowDrums)

### Agents Working Group

- [Peter Alexander](https://github.com/poita)
- [Luca Chang](https://github.com/LucaButBoring)
- [Inna Harper](https://github.com/ihrpr)

### MCP Apps Working Group

- [Liad Yosef](https://github.com/liady)
- [Ido Salomon](https://github.com/idosal)

### Progressive Disclosure Working Group

- [Tapan Chugh](https://github.com/chughtapan)
- [Sam Morrow](https://github.com/SamMorrowDrums)
- [Kurtis Van Gent](https://github.com/kurtisvg)

### Tool Annotations Interest Group

- [Sam Morrow](https://github.com/SamMorrowDrums)

### Tool Scopes Working Group

- [Sam Morrow](https://github.com/SamMorrowDrums)

## About This Document

This document is updated by the MCP maintainers and reflects the current
governance structure. For more information about MCP governance, see our
[governance documentation](https://modelcontextprotocol.io/community/governance).
