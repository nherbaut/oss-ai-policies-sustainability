# Contributor Covenant Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our community a
harassment-free experience for everyone, regardless of age, body size, visible or
invisible disability, ethnicity, sex characteristics, gender identity and expression,
level of experience, education, socio-economic status, nationality, personal appearance,
race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse,
inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment for our community
include:

- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Accepting responsibility and apologizing to those affected by our mistakes, and
  learning from the experience
- Focusing on what is best not just for us as individuals, but for the overall community

Examples of unacceptable behavior include:

- The use of sexualized language or imagery, and sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information, such as a physical or email address, without
  their explicit permission
- Bringing third-party AI notetakers, meeting bots, or other unofficial recording or
  transcription tools into community meetings (see [Community Meetings](#community-meetings))
- Other conduct which could reasonably be considered inappropriate in a professional
  setting

## Community Meetings

Working Group, Interest Group, and other community meetings use the official Google Meet
transcription, enabled by the meeting host. Participants who want a record of a meeting
should use that transcript and the published meeting notes.

Participants must not add third-party AI notetakers, meeting bots, or other automated
recording or transcription services (such as Otter.ai, Fireflies.ai, Read.ai, or similar
tools) to community meetings, whether by inviting them directly or by letting them join
automatically from a personal calendar or account. Participants also must not record or
transcribe meetings with their own tools. These services capture the voices and words of
everyone present without their consent, and store that data under terms the project does
not control.

Meeting hosts may remove unauthorized bots from a meeting at any time without notice.
Repeatedly bringing bots or unofficial recording tools into meetings is a violation of
this Code of Conduct and is handled under the [Enforcement Guidelines](#enforcement-guidelines).

## Enforcement Responsibilities

Community leaders are responsible for clarifying and enforcing our standards of
acceptable behavior and will take appropriate and fair corrective action in response to
any behavior that they deem inappropriate, threatening, offensive, or harmful.

Community leaders have the right and responsibility to remove, edit, or reject comments,
commits, code, wiki edits, issues, and other contributions that are not aligned to this
Code of Conduct, and will communicate reasons for moderation decisions when appropriate.

## Scope

This Code of Conduct applies within all community spaces, and also applies when an
individual is officially representing the community in public spaces. Examples of
representing our community include using an official e-mail address, posting via an
official social media account, or acting as an appointed representative at an online or
offline event.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to
the community leaders responsible for enforcement at mcp-coc@anthropic.com. All
complaints will be reviewed and investigated promptly and fairly.

All community leaders are obligated to respect the privacy and security of the reporter
of any incident.

## Enforcement Guidelines

Community leaders will follow these Community Impact Guidelines in determining the
consequences for any action they deem in violation of this Code of Conduct:

### 1. Correction

**Community Impact**: Use of inappropriate language or other behavior deemed
unprofessional or unwelcome in the community.

**Consequence**: A private, written warning from community leaders, providing clarity
around the nature of the violation and an explanation of why the behavior was
inappropriate. A public apology may be requested.

### 2. Warning

**Community Impact**: A violation through a single incident or series of actions.

**Consequence**: A warning with consequences for continued behavior. No interaction with
the people involved, including unsolicited interaction with those enforcing the Code of
Conduct, for a specified period of time. This includes avoiding interactions in community
spaces as well as external channels like social media. Violating these terms may lead to
a temporary or permanent ban.

### 3. Temporary Ban

**Community Impact**: A serious violation of community standards, including sustained
inappropriate behavior.

**Consequence**: A temporary ban from any sort of interaction or public communication
with the community for a specified period of time. No public or private interaction with
the people involved, including unsolicited interaction with those enforcing the Code of
Conduct, is allowed during this period. Violating these terms may lead to a permanent
ban.

### 4. Permanent Ban

**Community Impact**: Demonstrating a pattern of violation of community standards,
including sustained inappropriate behavior, harassment of an individual, or aggression
toward or disparagement of classes of individuals.

**Consequence**: A permanent ban from any sort of public interaction within the
community.

## Appeals

If you believe an enforcement action taken against you was made in error, you may appeal
it by emailing appeals@modelcontextprotocol.io. This channel exists specifically for
appealing Code of Conduct enforcement actions, including organization-level bans.

Because appeals are handled over email rather than on GitHub, you can reach the team even
if your access to GitHub repositories, issues, or pull requests has been removed as part
of an enforcement action.

When submitting an appeal, please include:

- The account or username affected by the action
- The action you are appealing (for example, a temporary or permanent ban)
- Why you believe the action should be reconsidered, with thorough evidence supporting
  any surrounding context

Appeals are reviewed by the moderation and lead maintainer team. While we will make an
effort to respond to appeals filed in good faith, bandwidth constraints mean we may not
be able to respond to every appeal. We will only review one appeal per enforcement action,
so please be thorough when submitting your appeal.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant][homepage], version 2.0,
available at https://www.contributor-covenant.org/version/2/0/code_of_conduct.html.

Community Impact Guidelines were inspired by
[Mozilla's code of conduct enforcement ladder](https://github.com/mozilla/diversity).

[homepage]: https://www.contributor-covenant.org

For answers to common questions about this code of conduct, see the FAQ at
https://www.contributor-covenant.org/faq. Translations are available at
https://www.contributor-covenant.org/translations.
