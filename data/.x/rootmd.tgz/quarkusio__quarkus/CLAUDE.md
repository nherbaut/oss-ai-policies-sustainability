@AGENTS.md

# Quarkus Coding Conventions

## Skills

When performing specific tasks, read the relevant skill file for detailed
guidance before starting work:

- **Writing build steps** — Read `.agents/skills/writing-build-steps/SKILL.md`
  when creating or modifying `@BuildStep` methods, build items, or recorders.
- **Writing tests** — Read `.agents/skills/writing-tests/SKILL.md`
  when creating or modifying tests for Quarkus extensions.
- **Working with config** — Read `.agents/skills/working-with-config/SKILL.md`
  when creating or modifying `@ConfigMapping` configuration interfaces.
- **Classloading and runtime-dev** — Read `.agents/skills/classloading-and-runtime-dev/SKILL.md`
  when working with runtime-dev modules, conditional dependencies, or debugging classloading.
- **Creating extensions** — Read `.agents/skills/creating-extensions/SKILL.md`
  when creating a new extension or understanding the full module layout.
- **Coding style** — Read `.agents/skills/coding-style/SKILL.md`
  when unsure about formatting, naming, visibility, or logging conventions.
- **Building and testing** — Read `.agents/skills/building-and-testing/SKILL.md`
  when building, testing, or understanding Maven flags and build commands.
- **Pull requests** — Read `.agents/skills/pull-requests/SKILL.md`
  when preparing a pull request, writing commit messages, or choosing labels.
- **Building docs** — Read `.agents/skills/building-docs/SKILL.md`
  when building, previewing, or testing documentation changes locally.
- **Manage deprecations** — Read `.agents/skills/manage-deprecations/SKILL.md`
  when removing code that has been deprecated for over 12 months, adding
  `@Deprecated` annotations that were missed on companions of a deprecated
  element, or applying a new deprecation the user requests.
- **Converting recorders to services** — Read `.agents/skills/converting-recorders-to-services/SKILL.md`
  when converting extensions from `@Record`/`@Recorder` to `ServiceRegistrar` services.
